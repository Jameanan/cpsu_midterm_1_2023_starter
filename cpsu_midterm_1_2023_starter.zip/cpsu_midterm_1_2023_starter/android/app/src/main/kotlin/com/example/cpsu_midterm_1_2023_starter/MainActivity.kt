package com.example.cpsu_midterm_1_2023_starter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
